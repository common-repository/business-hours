Business Hours:

TO USE:

Insert

if(function_exists('echo_hours')) {
echo_hours();
}

where you would like your hours to show up.


Styling with CSS:

The plugin is contained inside of a DIV with the ID 'biz_hours_container'. You may style the container by adding a rule #biz_hours_container inside of your style.css file.

The days as well as hours can be styled individually. The default ID for these DIV's is biz_hours_day and biz_hours_hour respectively.
